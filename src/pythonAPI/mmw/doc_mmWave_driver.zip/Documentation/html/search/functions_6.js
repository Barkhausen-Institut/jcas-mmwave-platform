var searchData=
[
  ['transceive_76',['transceive',['../classmmw_1_1mmw_1_1ni__mmw.html#ad46bf55d52f97bdcf77a94490ab1ae8e',1,'mmw::mmw::ni_mmw']]],
  ['trigger_5fburst_77',['trigger_burst',['../classmmw_1_1mmw_1_1ni__mmw.html#a0e5fb76aef2552f2aa0622da47b0e533',1,'mmw::mmw::ni_mmw']]],
  ['trigger_5fsync_5fenable_78',['trigger_sync_enable',['../classmmw_1_1mmw_1_1ni__mmw.html#ab1f977d4d625b6646ea9d65b4a2071cd',1,'mmw::mmw::ni_mmw']]]
];
