var indexSectionsWithContent =
{
  0: "_bcdeghilmnopstw",
  1: "bcdghilnoptw",
  2: "m",
  3: "_cegistw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions"
};

