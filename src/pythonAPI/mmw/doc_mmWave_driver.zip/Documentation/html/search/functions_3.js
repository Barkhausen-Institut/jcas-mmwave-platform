var searchData=
[
  ['get_5fconfig_67',['get_config',['../classmmw_1_1mmw_1_1ni__mmw.html#a3d892ec1f6f029760b34917816d8cdd8',1,'mmw::mmw::ni_mmw']]]
];
