"""@mainpage Authors
mmw.py - mmmWave driver module for NI mmW Test System and its LabVIEW driver

Author(s): NOFFZ Technologies GmbH, Vuk Obradovic and Peter Vago, 2020
"""